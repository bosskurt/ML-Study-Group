<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Page</title>
    <link href="page.css" type="text/css" rel="stylesheet">
    <script src="jq/jquery-3.3.1.min.js"></script>
</head>
<!--------------------------------------------------------------Navigatiob bar---------------------------------------------------------------------------->
<body>
<div id="nav_bar">
    <div id="nav_bar_center">
        <div id="nav_bar_left">
            <div id="nav_bar_left_img">
                <img src="img/trip-chiz-logo-2.png">
            </div>
            <div id="nav_bar_left_search">
                <div id="search_icon"></div>
                <input type="text" placeholder="Search here...">
            </div>
        </div>

        <div id="nav_bar_right">

            <div class="set" style="float: right;height: 30px;width: 30px;">

                <div class="pimg"></div>

            </div>

            <div style="float: right;height:25px;width:25px;margin-right: 21px">

                <div class="Not"></div>

            </div>

            <div style="float: right;height:25px;width:25px;margin-right: 21px;">

                <div class="mes"></div>

            </div>
            <div style="float: right;height:25px;width:25px;margin-right: 21px;">

                <a href="newsfeed.php"><div class="newsfeed"></div></a></div>

            <div style="float: right;height:25px;width:25px;margin-right: 21px;">
                <a href="profile.php"> <div class="profile">

                </div>
                </a>
            </div>
        </div>
    </div>
</div>
<!-------------------------------------------------------------Setting and notifications Sub Div-------------------------------------------------------->
<div class="notification"></div>

<div class="setting">
    <ul id="setting_ul">
        <li style="height: 40px;font-size: 15pt;">
            Ramin Zamani
        </li>
        <span class="line"></span>
        <li>
            Settings
        </li>
        <li>
            Privacy
        </li>
        <span class="line"></span>
        <li>
            Log Out
        </li>
    </ul>
</div>

<div class="messag"></div>
<!-------------------------------------------------------------Cover IMG and Profile IMG And Menu-------------------------------------------------------->
<div id="content">
    <div id="content_left">
        <div id="cover_img">
            <button id="cover_img_update"></button>
        </div>
        <div id="profile_img" class="pimg">
            <button id="profile_img_update"></button>
        </div>
        <div id="profile_name">
            <p>Ramin Zamani</p>
        </div>
        <div id=status_bar>
            <ul>
                <li>
                    <a id="timeline">Home
                        <span id="status_bar_pramid"></span>
                    </a>

                </li>
            </ul>
            <ul>
                <li>
                    <a id="about">About
                        <span id="status_bar_pramid"></span>
                    </a>
                </li>
            </ul>
            <ul>
                <li>
                    <a id="photos">Photos
                        <span id="status_bar_pramid"></span>
                    </a>
                </li>
            </ul>
            <ul>
                <li>
                    <a id="videos">Videos
                        <span id="status_bar_pramid"></span>
                    </a>
                </li>
            </ul>

        </div>
        <section id="section_home"></section>
        <section id="section_about"></section>
        <section id="section_photos">

            <div id="content_photos">

                <div id="content_photos_icon">
                    <div id="content_photos_icon_img">
                        <img src="img/picture.png">
                    </div>
                    <div id="content_photos_icon_text">
                        <p>Photos</p>
                    </div>
                </div>


                <div id="photos_content_down">


                    <div id="photos_content_down_right"></div>


                    <div id="photos_content_down_left">
                        <div class="photos_content_down_left_box">
                            <div id="show_imgs" class="photos_single_img"></div>
                            <div class="photos_txt">Single photos</div>
                        </div>

                        <div class="photos_content_down_left_box">
                            <div class="photos_album_img"></div>
                            <div class="photos_txt">Make Album</div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <section id="section_videos">

            <div id="content_videos">
                <div id="content_videos_icon">
                    <div id="content_videos_icon_img">
                        <img src="img/video-player.png">
                    </div>
                    <div id="content_videos_icon_text">
                        <p>Videos</p>
                    </div>
                </div>


                <div id="vidoe_box">
                    <span id="video_upload"></span>
                </div>


            </div>

        </section>
    </div>


    <div id="content_right"></div>
</div>

<script>

    $('#about').click(function () {
        $('#section_home').hide();
        $('#section_about').fadeIn();
        $('#section_photos').hide();
        $('#section_videos').hide();
    });
    $('#timeline').click(function () {
        $('#section_home').fadeIn();
        $('#section_about').hide();
        $('#section_photos').hide();
        $('#section_videos').hide();
    });
    $('#photos').click(function () {
        $('#section_home').hide();
        $('#section_about').hide();
        $('#section_photos').fadeIn();
        $('#section_videos').hide();
    });
    $('#videos').click(function () {
        $('#section_home').hide();
        $('#section_about').hide();
        $('#section_photos').hide();
        $('#section_videos').fadeIn();
    });

    $('.Not').click(function () {
        $('.notification').fadeToggle();
        $('.setting').hide();
        $('.messag').hide();
    });
    $('.set').click(function () {
        $('.setting').fadeToggle();
        $('.notification').hide();
        $('.messag').hide();
    });
    $('.mes').click(function () {
        $('.messag').fadeToggle();
        $('.notification').hide();
        $('.setting').hide();
    });
</script>
</body>
</html>