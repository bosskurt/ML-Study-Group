<?php
include('db.php');
session_start();

// initializing some variables
$email = "";
$errors = array(); 
$order_total = 0;

// CONNECT TO THE DATABASE
$db = mysqli_connect($db_hostname, $db_username, $db_password, $db_database );
//$con = mysql_connect($db_hostname,$db_username,$db_password, $db_database);

// CHECKING CONNECTION
if($db === false){
    die("1 - ERROR: Could not connect. " . mysqli_connect_error());
}


// CHECKING IF THE TABLE EXIST
$table_check = "SELECT * FROM `user`";
if($db->query($table_check) == FALSE) {
	echo  '<center><font color="red">Table \'tripchiz.user\' doesn\'t exist. >><a href="back-end/install.php"><font color="black">click here</font></a><< to create the table, then come back to continue</font></center>';
}
// REGISTER USER
	if (isset($_POST['signup_reg'])) {
		// receive all input values from the form
		$email = strtolower(mysqli_real_escape_string($db, $_POST['email']));
		$name = strtolower(mysqli_real_escape_string($db, $_POST['name']));
		$surname = strtolower(mysqli_real_escape_string($db, $_POST['surname']));
		$password = mysqli_real_escape_string($db, $_POST['password']);
		$password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

		// form validation:
		if (empty($email)) { array_push($errors, "Email is required"); }
		if (empty($name)) { array_push($errors, "Name is required"); }
		if (empty($surname)) { array_push($errors, "Surname is required"); }
		if (empty($password)) { array_push($errors, "Password is required"); }
		if ($password != $password_2) {
			array_push($errors, "The two passwords do not match");
		}

		// checking if the user exists
		$user_check_query = "SELECT * FROM user WHERE email='$email' LIMIT 1";
		$result = mysqli_query($db, $user_check_query);
		$user = mysqli_fetch_assoc($result);
		
		// if user exists
		if ($user) { 
			if ($user['email'] === $email) {
				array_push($errors, "Email already exists");
			}
		}
	
		// if user does not exist
		if (count($errors) == 0) {
			$password = md5($password);//encrypt the password
			$query = "INSERT INTO user (email, name, surname, password) VALUES('$email', '$name', '$surname', '$password')";
			mysqli_query($db, $query);
			$_SESSION['email'] = email;
			$_SESSION['success'] = "You are now logged in";
			header('location: profile.php');
		}
		
	
	}
?>