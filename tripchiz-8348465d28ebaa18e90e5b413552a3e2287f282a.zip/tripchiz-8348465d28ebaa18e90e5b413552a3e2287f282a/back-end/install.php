<?php
$db_hostname = 'localhost';
$db_username = 'root';
$db_password = '124578';
$db_database = 'tripchiz';

// connect to the database
$db = mysqli_connect($db_hostname, $db_username, $db_password, $db_database);

if($db === false){
    die("1 - ERROR: Could not connect. " . mysqli_connect_error());
} else {
	echo "1  - Logged In <br/><br/>";
	
	$table_check = "SELECT * FROM `user`";
	if($db->query($table_check) == TRUE) {
		echo "2 - Table 'user' already exists <br/><br/>";
	}
	else {
		// create table in the database
		$create_user = "CREATE TABLE `user` (
			`id` int(15) NOT NULL UNIQUE AUTO_INCREMENT,
			`email` VARCHAR(100) NOT NULL UNIQUE,
			`name` VARCHAR(100) NOT NULL UNIQUE,
			`surname` VARCHAR(100) NOT NULL,
			`password` VARCHAR(100) NOT NULL,
			`creation_date` TIMESTAMP,
			PRIMARY KEY (id, email)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1";
		if ($db->query($create_user) == TRUE) {
			echo "2 - Table 'user' created successfully <br/><br/>";
		}
		else {
			echo "2 - Error creating table: 'user' <br/><br/>";
		}
		
		$insertuser = "INSERT INTO `user` VALUES 	('1006001','johnjane@email.com','John','Jane','e10adc3949ba59abbe56e057f20f883e','2018-03-25 10:34:09')";	
		if ($db->query($insertuser) == TRUE) {
			echo "2.1 - Values inserted into 'user' successfully <br/><br/>";
		}
		else {
			echo "2.1 - Error inserting values into table: 'user' <br/><br/>";
		}
		
		$ALTER_id = "ALTER TABLE `user` AUTO_INCREMENT = 1006001";
		if ($db->query($ALTER_id) == TRUE) {
			echo "2.2 - User 'id' ALTERED successfully <br/><br/>";
		}
		else {
			echo "2.2 - Error altering table: 'user' <br/><br/>";
		}
	}
}
?> 