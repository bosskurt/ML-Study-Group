<?php
#
#Mysql server name:
#		IP or HOSTNAME : PORT number
#
$db_hostname = 'localhost:3306';
#
#Mysql user name:
#
$db_username = 'root';
#
#Mysql user password:
#
$db_password = '124578';
#
#Mysql database name:
#
$db_database = 'tripchiz';
#
#
?>