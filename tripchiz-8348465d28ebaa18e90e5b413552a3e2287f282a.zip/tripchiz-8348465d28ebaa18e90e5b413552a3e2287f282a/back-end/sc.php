<?php

$config['base_url']	= 'http://127.0.0.1/aaa/';

$config['index_page'] = 'index.php';