<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TripChiz</title>
    <link href="newsfeed.css" type="text/css" rel="stylesheet">
    <script src="jq/jquery-3.3.1.min.js"></script>
</head>
<body>
<div id="nav_bar">
    <div id="nav_bar_center">
        <div id="nav_bar_left">
            <div id="nav_bar_left_img">
                <img src="img/trip-chiz-logo-2.png">
            </div>
            <div id="nav_bar_left_search">
                <div id="search_icon"></div>
                <input type="text" placeholder="Search here...">
            </div>
        </div>

        <div id="nav_bar_right">
            <div class="set" style="float: right;height: 30px;width: 30px;">
                <div class="pimg"></div>

            </div>
            <div style="float: right;height:25px;width:25px;margin-right: 21px">
                <div class="Not">

                </div>

            </div>
            <div style="float: right;height:25px;width:25px;margin-right: 21px;">
                <div  class="mes">

                </div>
            </div>
            <div style="float: right;height:25px;width:25px;margin-right: 21px;">
                <a href="profile.php"> <div class="profile">

                </div>
                </a>
            </div>
            <div style="float: right;height: 100%;width: 120px;"></div>
        </div>
    </div>
</div>
<!------------------------------------------------------------Setting and notifications Sub Div----------------------------------->
<div class="notification"></div>

<div class="setting">
    <ul id="setting_ul">
        <li style="height: 40px;font-size: 15pt;">
            Ramin Zamani
        </li>
        <span class="line"></span>
        <li>
            Settings
        </li>
        <li>
            Privacy
        </li>
        <span class="line"></span>
        <li>
            Log Out
        </li>
    </ul>
</div>

<div class="messag"></div>
<!--------------------------------------------------* Content Down_left *------------------------------------------------>
<div id="content_down">
    <div id="content_left">
        <div id="cover_img"></div>
        <div id="profile_img" class="pimg">
            <span id="profile_name"> Ramin Zamani</span>
        </div>


        <div id="groups">
            <img class="imgs" src="img/group.png">
            <span class="name">Groups</span>
        </div>
        <div id="groups_content">
            <div class="groups_content_join"></div>
        </div>


        <div id="pages">
            <img class="imgs" src="img/menu.png" style="height: 40px;">
            <span class="name">Pages</span>
        </div>
        <div id="pages_content">
            <div class="pages_content_join"></div>
            <div class="pages_content_join"></div>

        </div>


        <div id="community">
            <img class="imgs"  src="img/chat.png">
            <span class="name">Community</span>
        </div>
        <div id="community_content">
            <div class="community_content_join"></div>
            <div class="community_content_join"></div>
            <div class="community_content_join"></div>

        </div>

    </div>


    <!--------------------------------------------------* Content Down_Center *------------------------------------------------>
    <div class="scroll">
    <div id="content_center">

        <div id="container">
                <div id="top">
                    <span id="pimg_small" class="pimg"></span>
                    <span class="name_container">Ramin</span>
                    <img id="logo" src="img/settings-work-tool.png">
                    <div class="post_setting"></div>
                </div>
                <div id="content1">
                    <textarea id="input_text" placeholder="What's on your mind..."></textarea>
                    <span id="input_img"></span>
                    <span id="input_video"></span>
                    <span id="live_video"></span>
                </div>
                <span id="post">
                <input type="submit" value="Post">
            </span>
        </div>

    </div>



    <!--------------------------------------------------* Content Down_Right *------------------------------------------------>





    <div id="content_right"></div>
    </div>
</div>
<!--------------------------------------------------* JQ*------------------------------------------------------------------------->

<script>

    $('#groups').click(function () {
        $('#groups_content').fadeToggle();
    });
    $('#pages').click(function () {
        $('#pages_content').fadeToggle();
    });
    $('#community').click(function () {
        $('#community_content').fadeToggle();
    });
    $('.Not').click(function () {
        $('.notification').fadeToggle();
        $('.setting').hide();
        $('.messag').hide();
    });
    $('.set').click(function () {
        $('.setting').fadeToggle();
        $('.notification').hide();
        $('.messag').hide();
    });
    $('.mes').click(function () {
        $('.messag').fadeToggle();
        $('.notification').hide();
        $('.setting').hide();
    });
    $('#logo').click(function () {
        $('.post_setting').fadeToggle();
    });

</script>
</body>
</html>