<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ramin Zamani</title>
    <link href="index.css" type="text/css" rel="stylesheet">
    <script src="jq/jquery-3.3.1.min.js"></script>
</head>

<!--------------------------------------------------------------Navigatiob bar---------------------------------------------------------------------------->
<body>
<div id="nav_bar">
    <div id="nav_bar_center">
        <div id="nav_bar_left">
            <div id="nav_bar_left_img">
                <img src="img/trip-chiz-logo-2.png">
            </div>
            <div id="nav_bar_left_search">
                <div id="search_icon"></div>
                <input type="text" placeholder="Search here...">
            </div>
        </div>

        <div id="nav_bar_right">

            <div class="set" style="float: right;height: 30px;width: 30px;">

                <div class="pimg"></div>

            </div>

            <div style="float: right;height:25px;width:25px;margin-right: 21px">

                <div class="Not"></div>

            </div>

            <div style="float: right;height:25px;width:25px;margin-right: 21px;">

                <div class="mes"></div>

            </div>
            <div style="float: right;height:25px;width:25px;margin-right: 21px;">

                <a href="newsfeed.php"><div class="newsfeed"></div></a>

            </div>

            <div style="float: right;height: 25px;width:25px;"></div>
        </div>
    </div>
</div>
<!-------------------------------------------------------------Setting and notifications Sub Div-------------------------------------------------------->
<div class="notification"></div>

<div class="setting">
    <ul id="setting_ul">
        <li style="height: 40px;font-size: 15pt;">
            Ramin Zamani
        </li>
        <span class="line"></span>
        <li>
          Settings
        </li>
        <li>
            Privacy
        </li>
        <span class="line"></span>
        <li>
            Log Out
        </li>
    </ul>
</div>

<div class="messag"></div>
<!-------------------------------------------------------------Cover IMG and Profile IMG And Menu-------------------------------------------------------->
<div id="content">
    <div id="cover_img">
        <button id="cover_img_update"></button>
    </div>
    <div id="profile_img" class="pimg">
        <button id="profile_img_update"></button>
    </div>
    <div id="profile_name">
        <p>Ramin Zamani</p>
    </div>
    <div id=status_bar>
        <ul>
            <li>
                <a id="timeline">TimeLine
                    <span></span>
                </a>

            </li>
        </ul>
        <ul>
            <li>
                <a id="about">About
                    <span></span>
                </a>
            </li>
        </ul>
        <ul>
            <li>
                <a id="friends">Friends
                    <span></span>
                </a>
            </li>
        </ul>

        <ul>
            <li>
                <a id="photos">Photos
                    <span></span>
                </a>
            </li>
        </ul>
        <ul>
            <li>
                <a id="videos">Videos
                    <span></span>
                </a>
            </li>
        </ul>
        <ul>
            <li>
                <a id="travels">Travels
                    <span></span>
                </a>
            </li>
        </ul>
    </div>
</div>

<!----------------------------------------------------------Content Down After Cover(Timeline)------------------------------------------------------------>

<div id="content_down">
    <div id="content_down_right">
    </div>


    <div id="content_timline">
        <div id="content_down_left_center">
            <div id="container">
                <div id="top">
                    <span id="pimg_small" class="pimg"></span>
                    <span class="name_container">Ramin</span>
                    <img id="logo" src="img/settings-work-tool.png">
                    <div class="post_setting"></div>
                </div>
                <div id="content1">
                    <textarea id="input_text" placeholder="What's on your mind..."></textarea>
                    <span id="input_img"></span>
                    <span id="input_video"></span>
                    <span id="live_video"></span>
                </div>
                <span id="post">
                <input type="submit" value="Post">
            </span>
            </div>
        </div>
        <!-------------------------------------------------------------Left Pages-Groups-------------------------------------------------------------->

        <div id="content_down_left_left">
            <!--------------------------------------------------------------Groups------------------------------------------------------>
            <div id="groups_info">
                <div id="groups_info_icon">
                    <div id="groups_info_icon_img">
                        <img src="img/group2.png">
                    </div>
                    <div id="groups_info_icon_text">
                        <p>Groups</p>
                    </div>
                </div>
                <div id="content_groups">
                    <div id="content_groups_info">
                        <span></span>
                    </div>
                </div>
            </div>
            <!--------------------------------------------------------------Pages------------------------------------------------------------>
            <div id="pages_info">
                <div id="pages_info_icon">
                    <div id="pages_info_icon_img">
                        <img src="img/menu2.png">
                    </div>
                    <div id="pages_info_icon_text">
                        <p>Pages</p>
                    </div>
                </div>
                <div id="content_pages">
                    <div id="content_pages_info">
                        <span></span>
                    </div>
                </div>
            </div>
            <!----------------------------------------------------------------Community------------------------------------------------------->
            <div id="community_info">
                <div id="community_info_icon">
                    <div id="community_info_icon_img">
                        <img src="img/chat2.png">
                    </div>
                    <div id="community_info_icon_text">
                        <p>Community</p>
                    </div>
                </div>
                <div id="content_community">
                    <div id="content_community_info">
                        <span></span>
                    </div>
                </div>
            </div>
            <!------------------------------------------------------------------Contents left------------------------------------------------------>
            <div id="groups">
                <div id="groups_icon">
                    <img src="img/group.png">
                </div>
                <div id="groups_text">
                    <p>Groups</p>
                </div>
            </div>


            <div id="pages">
                <div id="pages_icon">
                    <img src="img/menu.png" style="height: 45px;">
                </div>
                <div id="pages_text">
                    <p>Pages</p>
                </div>
            </div>

            <div id="community">
                <div id="community_icon">
                    <img src="img/chat.png">
                </div>
                <div id="community_text">
                    <p>Community</p>
                </div>
            </div>

        </div>
    </div>

</div>
<!---------------------------------------------------------------Content About Menu bar---------------------------------------------------------------->
<div id="content_about">
    <div id="content_about_icon">
        <div id="content_about_icon_img">
            <img src="img/users.png">
        </div>
        <div id="content_about_icon_text">
            <p>About</p>
        </div>
    </div>
    <table id="table">
        <tr class="tbl_about">
            <td>
                <span class="color">Name:</span><span class="answer">Ramin</span>
            </td>
            <td>
                <span class="color">Surname:</span><span class="answer">Zamanighiri</span>
            </td>
        </tr>
        <tr class="tbl_about">
            <td>
                <span class="color">Data of birth:</span><span class="answer">16.4.1992</span>
            </td>
            <td>
                <span class="color">Place of birth:</span><span class="answer">Ghir, Iran</span>
            </td>
        </tr>
        <tr class="tbl_about">
            <td>
                <span class="color">Home town:</span><span class="answer">Shiraz, Iran</span>
            </td>
            <td>
                <span class="color">Live in:</span><span class="answer"> Kuala Lumpur, Malaysia</span>
            </td>
        </tr>
        <tr class="tbl_about">
            <td>
                <span class="color">E-mail:</span><span class="answer">zamaniramin549@gmail.com</span>
            </td>
            <td>
                <span class="color">Contact number:</span><span class="answer">+601123792799</span>
            </td>
        </tr>
        <tr class="tbl_about">
            <td>
                <span class="color">Relationship:</span><span class="answer">Single</span>
            </td>
        </tr>
    </table>

</div>

<!---------------------------------------------------------------Content Friends Menu bar------------------------------------------------------------->
<div id="content_friends">
    <div id="content_friends_icon">
        <div id="content_friends_icon_img">
            <img src="img/trusting-in-someone.png">
        </div>
        <div id="content_friends_icon_text">
            <p>Friends</p>
        </div>
        <div id="friend_search">
            <input type="text" placeholder="Find a friend...">
        </div>
    </div>


    <div id="friend_content_down">


        <div id="friend_content_down_right"></div>


        <div id="friend_content_down_left">
            <div class="friend_content_down_left_box">
                <div class="friend_zone_img"></div>
                <div class="friend_zone_txt">Make Friend zone</div>
            </div>

            <div id="show_friends" class="friend_content_down_left_box">
                <div class="friend_img"></div>
                <div class="friend_zone_txt">Freinds</div>
            </div>
        </div>
    </div>


</div>

<!-------------------------------------------------------------------Content Photos Menu bar----------------------------------------------------------->
<div id="content_photos">
    <div id="content_photos_icon">
        <div id="content_photos_icon_img">
            <img src="img/picture.png">
        </div>
        <div id="content_photos_icon_text">
            <p>Photos</p>
        </div>
    </div>


    <div id="photos_content_down">


        <div id="photos_content_down_right"></div>


        <div id="photos_content_down_left">
            <div class="photos_content_down_left_box">
                <div id="show_imgs" class="photos_single_img"></div>
                <div class="photos_txt">Single photos</div>
            </div>

            <div class="photos_content_down_left_box">
                <div class="photos_album_img"></div>
                <div class="photos_txt">Make Album</div>
            </div>
        </div>
    </div>

</div>
<!--------------------------------------------------------ontent Videos Menu bar----------------------------------------------->
<div id="content_videos">
    <div id="content_videos_icon">
        <div id="content_videos_icon_img">
            <img src="img/video-player.png">
        </div>
        <div id="content_videos_icon_text">
            <p>Videos</p>
        </div>
    </div>


    <div id="vidoe_box">
        <span id="video_upload"></span>
    </div>


</div>

</div>
<!-------------------------------------------------------------ontent Travel Menu bar------------------------------------------------------------------->
<div id="content_travels">
    <div id="content_travels_icon">
        <div id="content_travels_icon_img">
            <img src="img/air-transport.png">
        </div>
        <div id="content_travels_icon_text">
            <p>Travels</p>
        </div>
    </div>

</div>

<!------------------------------------------------------------------------------------------------------------------------------------------------------->
<script>

    $('#about').click(function () {
        $('#content_about').fadeIn();
        $('#content_timline').hide();
        $('#content_friends').hide();
        $('#content_photos').hide();
        $('#content_videos').hide();
        $('#content_travels').hide();
        $('#all_img_album').hide();
        $('#community_info').hide();
        $('#groups_info').hide();
        $('#pages_info').hide();
        $('#album').hide();
        $('#singimg').hide();
        $('#friend_friends_content').hide();
    });
    $('#timeline').click(function () {
        $('#content_timline').fadeIn();
        $('#content_about').hide();
        $('#content_friends').hide();
        $('#content_photos').hide();
        $('#content_videos').hide();
        $('#content_travels').hide();
        $('#all_img_album').hide();
        $('#community_info').hide();
        $('#groups_info').hide();
        $('#pages_info').hide();
        $('#album').hide();
        $('#singimg').hide();

    });
    $('#friends').click(function () {
        $('#content_friends').fadeIn();
        $('#content_timline').hide();
        $('#content_about').hide();
        $('#content_photos').hide();
        $('#content_videos').hide();
        $('#content_travels').hide();
        $('#all_img_album').hide();
        $('#community_info').hide();
        $('#groups_info').hide();
        $('#pages_info').hide();
        $('#album').hide();
        $('#singimg').hide();
        $('#friend_friends_content').hide();
        $('.friend_box').fadeIn();

    });
    $('#photos').click(function () {
        $('#content_photos').fadeIn();
        $('#content_friends').hide();
        $('#content_timline').hide();
        $('#content_about').hide();
        $('#content_videos').hide();
        $('#content_travels').hide();
        $('#all_img_album').hide();
        $('#community_info').hide();
        $('#groups_info').hide();
        $('#pages_info').hide();
        $('#album').hide();
        $('#singimg').hide();
        $('#content_photos_singleimg').fadeIn();
        $('#content_photos_album').fadeIn();
    });
    $('#videos').click(function () {
        $('#content_videos').fadeIn();
        $('#content_photos').hide();
        $('#content_friends').hide();
        $('#content_timline').hide();
        $('#content_about').hide();
        $('#content_travels').hide();
        $('#all_img_album').hide();
        $('#community_info').hide();
        $('#groups_info').hide();
        $('#pages_info').hide();
        $('#album').hide();
        $('#singimg').hide();

    });
    $('#travels').click(function () {
        $('#content_travels').fadeIn();
        $('#content_videos').hide();
        $('#content_photos').hide();
        $('#content_friends').hide();
        $('#content_timline').hide();
        $('#content_about').hide();
        $('#all_img_album').hide();
        $('#community_info').hide();
        $('#groups_info').hide();
        $('#pages_info').hide();
        $('#album').hide();
        $('#singimg').hide();

    });
    $('#groups').click(function () {
        $('#groups_info').show();
        $('#pages_info').hide();
        $('#community_info').hide();
        $('#album').hide();
        $('#singimg').hide();
    });
    $('#pages').click(function () {
        $('#pages_info').show();
        $('#groups_info').hide();
        $('#community_info').hide();
        $('#album').hide();
        $('#singimg').hide();

    });
    $('#community').click(function () {
        $('#community_info').show();
        $('#groups_info').hide();
        $('#pages_info').hide();
        $('#album').hide();
        $('#singimg').hide();
    });
    $('.Not').click(function () {
        $('.notification').fadeToggle();
        $('.setting').hide();
        $('.messag').hide();
    });
    $('.set').click(function () {
        $('.setting').fadeToggle();
        $('.notification').hide();
        $('.messag').hide();
    });
    $('.mes').click(function () {
        $('.messag').fadeToggle();
        $('.notification').hide();
        $('.setting').hide();
    });
    $('#logo').click(function () {
        $('.post_setting').fadeToggle();
    });

</script>
<!------------------------------------------------------------------------------------------------------------------------------------------------------>
</body>
</html>